//
//  HomeViewController.swift
//  FirebaseLogin
//
//  Created by Harun Sasmaz on 7.08.2020.
//  Copyright © 2020 Harun Sasmaz. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var welcomeLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
}
