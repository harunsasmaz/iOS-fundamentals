//
//  LoginViewController.swift
//  FirebaseLogin
//
//  Created by Harun Sasmaz on 7.08.2020.
//  Copyright © 2020 Harun Sasmaz. All rights reserved.
//

import UIKit
import FirebaseAuth

class LoginViewController: UIViewController {

    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var errorLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUpElements()
    }
    
    func setUpElements()
    {
        errorLabel.alpha = 0
        Utilities.styleTextField(emailTextField)
        Utilities.styleTextField(passwordTextField)
        Utilities.styleFilledButton(loginButton)
    }
    
    func validateFields() -> String? {
        
        let email = emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let pwd = passwordTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if email == "" || pwd == "" {
            return "Fields cannot be empty!"
        }
        
        if Utilities.isPasswordValid(pwd!) == false {
            return "Password Wrong Format!"
        }
        
        return nil
    }
    
    func showError(_ msg: String!) {
        errorLabel.text = msg
        errorLabel.alpha = 1
    }
    
    func transitionToHome() {
        let homeview = storyboard?.instantiateViewController(identifier: Constants.Storyboard.homeViewController) as? HomeViewController
        view.window?.rootViewController = homeview
        view.window?.makeKeyAndVisible()
    }
    
    
    @IBAction func loginTapped(_ sender: Any) {
        
        let err = validateFields()
        
        if err != nil {
            self.showError(err)
            return
        }
        
        let email = emailTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let pwd = passwordTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        
        Auth.auth().signIn(withEmail: email, password: pwd) { (result, err) in
            if err != nil {
                self.showError("Error: " + err!.localizedDescription)
            } else {
                self.transitionToHome()
            }
        }
        
    }
}
